﻿namespace Bookflix_Server.Models.DTOs
{
    public class CarritoItemActualizarDTO
    {
        public int IdLibro { get; set; }
        public int NuevaCantidad { get; set; }
    }

}
