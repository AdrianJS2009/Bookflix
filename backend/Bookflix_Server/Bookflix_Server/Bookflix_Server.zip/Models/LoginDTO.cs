﻿namespace Bookflix_Server.Models
{
    public class LoginDto
    {
        public string Email { get; set; }

        public string Password { get; set; }
    }
}
